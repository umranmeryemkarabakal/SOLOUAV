# tiltrotor_tailplane — Gazebo modeli (taşınabilir paket)

Bu paket, `mc_indi_tiltrotor` projesinde uçurulan **üç tilt rotorlu VTOL**
modelini başka bir bilgisayarda açmak için gereken her şeyi içerir.

Hazırlanma tarihi: 2026-08-04.

## İçindekiler

```
models/tiltrotor_tailplane/     ana model (model.sdf + model.config)
models/standard_vtol/           SADECE mesh bağımlılığı için
                                (model.sdf'in referansları: x8_wing.dae,
                                 iris_prop_ccw/cw.dae, x8_elevon_left/right.dae)
worlds/default.sdf              uçuşlarda kullanılan dünya
px4_airframe/4023_gz_tiltrotor_indi[.post]   PX4 airframe tanımı (SITL için)
```

Modeli tek başına görüntülemek için `models/` klasörü yeterlidir; `worlds/` ve
`px4_airframe/` yalnızca uçuşu tekrar kurmak isteyene lazımdır.

## Yalnızca modele bakmak (PX4 gerekmez)

```bash
export GZ_SIM_RESOURCE_PATH=/paketin/yolu/models:$GZ_SIM_RESOURCE_PATH
gz sim -v4 empty.sdf
# GUI'de sol üstteki "+" -> Resource Spawner -> tiltrotor_tailplane
```

veya doğrudan dünyayla:

```bash
export GZ_SIM_RESOURCE_PATH=/paketin/yolu/models:$GZ_SIM_RESOURCE_PATH
gz sim -v4 /paketin/yolu/worlds/default.sdf
```

Gazebo sürümü: bu paket **gz-sim 8 (Harmonic)** ile kullanıldı.

## Model hakkında bilinmesi gerekenler

- **Üç tilt rotoru:** iki kanat rotoru (`motor_0_joint`, `motor_1_joint`) ve bir
  kuyruk rotoru (`motor_2_joint`). Eklem aralığı **0-90°**; 0° = dik (multikopter),
  90° = tam ileri (sabit kanat).
- **Beş kontrol yüzeyi:** iki elevon, iki elevator, bir rudder. PX4 modülünde
  bunlar şu an **sürülmüyor** (`SURF_ENABLE = false`), yani sabit 0'da dururlar.
- **Servo eşlemesi** (airframe dosyası): Servo 1-5 = kontrol yüzeyleri,
  **Servo 6-8 = rotor tilt**. Gerçek tilt açısını izlemek için:
  ```bash
  gz topic -e -t /world/default/model/tiltrotor_indi_0/joint_state
  ```
- **Kuyruk panelleri `a0 = -0.2 rad` ile kurulu** — hız karesiyle büyüyen kalıcı
  bir AŞAĞI kuvvet üretirler (25 m/s'de ~34 N). Bu kasıtlıdır (burun ağır bir
  uçağı trimlemek için) ama kontrolcü onu göremez; modeli kullanacak olan bunu
  bilmeli.

## Kameraya dair bir uyarı (2026-08-04'te ölçüldü)

Gazebo'nun `/gui/follow` özelliği bu kurulumda kamerayı hedefe **yaklaştırmıyor** —
yalnızca yönünü çeviriyor. Araç 15 m/s'ye çıktığında ekranda birkaç piksel kalır
ve tilt açısı görünmez. `<follow_pgain>` eklemek (ne dünya dosyasına ne de
`~/.gz/sim/8/gui.config`'e) bunu çözmedi.

Çözüm proje deposundaki `sitl/gz_chase_cam.py`: model duruşunu okuyup kamerayı
`/gui/move_to/pose` ile elle sürer.

```bash
python3 gz_chase_cam.py tiltrotor_indi_0 0 -6 1.5    # gz FLU: +x ileri, +y SOL
```
