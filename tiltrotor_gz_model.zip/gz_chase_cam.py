#!/usr/bin/env python3
"""Drive the Gazebo GUI camera to chase the model -- a REPLACEMENT for /gui/follow.

WHY THIS EXISTS (2026-08-04). Every GUI run of this project showed the vehicle as
a handful of pixels, and it was blamed on the camera being "far". It is not a
distance setting: `/gui/follow/offset` reports success and does nothing in this
gz build. The camera keeps re-AIMING at the target (the vehicle stays dead centre
in every frame, measured) while never closing the distance, so at 40 m altitude
and 15 m/s the aircraft is ~4 px across and the tilt angle -- the one thing this
project's flights exist to show -- is invisible.

Two earlier fixes did not help and both are worth recording so they are not
retried: `<follow_pgain>1.0</follow_pgain>` in the world SDF (step 41), and the
same tag added to ~/.gz/sim/8/gui.config after discovering the user config
carries its OWN CameraTracking plugin and takes precedence. The gain was never
the problem -- the offset simply is not applied.

WHAT THIS DOES INSTEAD: reads the model pose from /world/default/pose/info and
commands an absolute camera pose via /gui/move_to/pose, at ~10 Hz. The offset is
expressed in the model's yawed frame, so the view stays a side/quarter shot as
the vehicle turns.

Usage:
    python3 gz_chase_cam.py [model] [dx dy dz]     # gz FLU: +x fwd, +y LEFT
    python3 gz_chase_cam.py tiltrotor_indi_0 0 -6 1.5
"""

from __future__ import annotations

import math
import subprocess
import sys
import time

MODEL = sys.argv[1] if len(sys.argv) > 1 else "tiltrotor_indi_0"
OFF = [float(v) for v in sys.argv[2:5]] if len(sys.argv) >= 5 else [0.0, -6.0, 1.5]
WORLD = "default"
RATE_HZ = 10.0


def model_pose():
    """Latest (x, y, z, yaw) of the model, or None.

    Reads ONE message from the pose topic. The topic carries every entity in the
    world, and the model's own pose is the entry whose name is exactly MODEL --
    link poses appear under their own names and are relative, so matching a
    prefix would silently pick up a nacelle.
    """
    try:
        out = subprocess.run(["gz", "topic", "-e", "-t", f"/world/{WORLD}/pose/info", "-n", "1"],
                             capture_output=True, text=True, timeout=5.0).stdout
    except Exception:
        return None

    # text protobuf: repeated `pose { name: "..." position { x: .. } orientation { .. } }`
    blocks = out.split("pose {")
    for b in blocks:
        if f'name: "{MODEL}"' not in b:
            continue

        def num(key, blk):
            i = blk.find(key)
            if i < 0:
                return None
            return float(blk[i + len(key):].split("\n", 1)[0].strip())

        pos_i = b.find("position {")
        ori_i = b.find("orientation {")

        if pos_i < 0 or ori_i < 0:
            continue

        pos = b[pos_i:ori_i]
        ori = b[ori_i:]
        x, y, z = num("x:", pos), num("y:", pos), num("z:", pos)
        qx, qy = num("x:", ori), num("y:", ori)
        qz, qw = num("z:", ori), num("w:", ori)

        if None in (x, y, z, qx, qy, qz, qw):
            continue

        yaw = math.atan2(2.0 * (qw * qz + qx * qy), 1.0 - 2.0 * (qy * qy + qz * qz))
        return x, y, z, yaw

    return None


def move_camera(px, py, pz, yaw, pitch):
    req = (f"pose: {{ position: {{ x: {px:.3f} y: {py:.3f} z: {pz:.3f} }} "
           f"orientation: {{ x: {0.0} y: {math.sin(pitch / 2):.6f} "
           f"z: {math.sin(yaw / 2):.6f} w: {math.cos(yaw / 2) * math.cos(pitch / 2):.6f} }} }}")
    subprocess.run(["gz", "service", "-s", "/gui/move_to/pose",
                    "--reqtype", "gz.msgs.GUICamera", "--reptype", "gz.msgs.Boolean",
                    "--timeout", "300", "--req", req],
                   capture_output=True, text=True)


def main():
    print(f"chase cam: {MODEL}, offset {OFF} (gz FLU), {RATE_HZ:.0f} Hz")
    misses = 0

    while True:
        p = model_pose()

        if p is None:
            misses += 1

            if misses > 50:
                print("model pose unavailable for 5 s -- stopping")
                return

            time.sleep(1.0 / RATE_HZ)
            continue

        misses = 0
        x, y, z, yaw = p
        c, s = math.cos(yaw), math.sin(yaw)
        # offset in the model's yawed frame
        cx = x + OFF[0] * c - OFF[1] * s
        cy = y + OFF[0] * s + OFF[1] * c
        cz = z + OFF[2]
        # aim back at the model
        dx, dy, dz = x - cx, y - cy, z - cz
        cam_yaw = math.atan2(dy, dx)
        cam_pitch = -math.atan2(dz, math.hypot(dx, dy))
        move_camera(cx, cy, cz, cam_yaw, cam_pitch)
        time.sleep(1.0 / RATE_HZ)


if __name__ == "__main__":
    main()
